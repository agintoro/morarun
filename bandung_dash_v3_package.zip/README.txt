BANDUNG DASH V3

New in V3:
- Combo multiplier up to x5
- 3 random missions per run
- Character skin selection
- Countdown start
- Pause screen
- One free revive
- Improved game-over summary
- Local best score
- Portrait-based face for the main character
- Single-file HTML, no external assets required

How to play:
- Open bandung_dash_v3.html in Safari on iPhone or any desktop browser.
- Swipe left/right to change lanes.
- Swipe up to jump.
- Swipe down to slide.
- Tap ♪ to toggle sound.
- Tap Ⅱ to pause.
